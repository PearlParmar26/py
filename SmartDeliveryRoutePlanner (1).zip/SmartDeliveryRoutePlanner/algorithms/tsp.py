"""
Smart Delivery Route Planning System - TSP algorithms
=====================================================

Problem: A delivery vehicle starts at a depot (location 0), must visit every
delivery location exactly once and return to the depot. Find the route with
the minimum total distance (the Travelling Salesman Problem).

Four algorithms are implemented and compared:
  1. Brute Force        - tries every permutation          O(n!)        exact
  2. Greedy (Nearest Neighbour)                            O(n^2)       approximate
  3. Dynamic Programming (Held-Karp, bitmask)              O(n^2 * 2^n) exact
  4. Branch and Bound (LC search, reduced cost matrix)     O(n! ) worst exact

Every function takes a distance matrix `dist` (list of lists, dist[i][j] is
the distance from i to j) and returns a dict:
    {
      "algorithm": name,
      "route": [0, a, b, ..., 0],   # starts and ends at the depot
      "cost": total distance,
      "stats": {...}                 # counters used for analysis
    }
"""

import heapq
import itertools
import math

INF = float("inf")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def euclidean_matrix(points):
    """Build a symmetric distance matrix from (x, y) coordinates."""
    n = len(points)
    dist = [[0.0] * n for _ in range(n)]
    for i in range(n):
        x1, y1 = points[i]
        for j in range(i + 1, n):
            x2, y2 = points[j]
            d = math.hypot(x1 - x2, y1 - y2)
            dist[i][j] = dist[j][i] = d
    return dist


def route_cost(dist, route):
    """Total length of a closed route like [0, 3, 1, 2, 0]."""
    return sum(dist[route[k]][route[k + 1]] for k in range(len(route) - 1))


def _trivial(dist, name):
    """Handle n <= 2, where there is only one possible route."""
    n = len(dist)
    if n == 0:
        return {"algorithm": name, "route": [], "cost": 0.0, "stats": {}}
    if n == 1:
        return {"algorithm": name, "route": [0, 0], "cost": 0.0, "stats": {}}
    route = [0, 1, 0]
    return {"algorithm": name, "route": route, "cost": route_cost(dist, route), "stats": {}}


# ---------------------------------------------------------------------------
# 1. Brute force  - baseline, exact
# ---------------------------------------------------------------------------
def brute_force(dist):
    """
    Fix the depot as the start and try all (n-1)! orders of the other cities.
    Time:  O(n!) routes, each costed in O(n)  ->  O(n * n!)
    Space: O(n) for the current permutation.
    """
    name = "Brute Force"
    n = len(dist)
    if n <= 2:
        return _trivial(dist, name)

    best_cost, best_route, checked = INF, None, 0
    for perm in itertools.permutations(range(1, n)):
        checked += 1
        cost = dist[0][perm[0]]
        for k in range(len(perm) - 1):
            cost += dist[perm[k]][perm[k + 1]]
            if cost >= best_cost:          # small early exit, same complexity
                break
        else:
            cost += dist[perm[-1]][0]
            if cost < best_cost:
                best_cost, best_route = cost, perm

    route = [0, *best_route, 0]
    return {"algorithm": name, "route": route, "cost": best_cost,
            "stats": {"routes_checked": checked}}


# ---------------------------------------------------------------------------
# 2. Greedy - Nearest Neighbour heuristic, approximate
# ---------------------------------------------------------------------------
def nearest_neighbour(dist, start=0):
    """
    From the current location always move to the closest unvisited one.
    Time:  n steps, each scans up to n cities  ->  O(n^2) in every case
    Space: O(n) for the visited array and the route.
    Not guaranteed optimal; for metric TSP the result can be O(log n) times
    the optimum in the worst case, but is usually 15-25% above it.
    """
    name = "Greedy (Nearest Neighbour)"
    n = len(dist)
    if n <= 2:
        return _trivial(dist, name)

    visited = [False] * n
    visited[start] = True
    route, cur, comparisons = [start], start, 0
    for _ in range(n - 1):
        nxt, best = -1, INF
        for j in range(n):
            if not visited[j]:
                comparisons += 1
                if dist[cur][j] < best:
                    best, nxt = dist[cur][j], j
        visited[nxt] = True
        route.append(nxt)
        cur = nxt
    route.append(start)
    # Rotate so the depot (0) is the first stop when start != 0
    if start != 0:
        i = route.index(0)
        route = route[i:-1] + route[:i] + [0]
    return {"algorithm": name, "route": route, "cost": route_cost(dist, route),
            "stats": {"comparisons": comparisons}}


# ---------------------------------------------------------------------------
# 3. Dynamic Programming - Held-Karp, exact
# ---------------------------------------------------------------------------
def held_karp(dist):
    """
    dp[mask][j] = shortest path that starts at 0, visits exactly the cities
    in `mask` (bit set = visited), and ends at city j.

        dp[{0}][0]          = 0
        dp[mask | 1<<k][k]  = min over j in mask ( dp[mask][j] + dist[j][k] )
        answer              = min over j ( dp[ALL][j] + dist[j][0] )

    Time:  2^n subsets * n end cities * n choices  ->  Theta(n^2 * 2^n)
    Space: Theta(n * 2^n) for the table (plus parent pointers).
    Best, average and worst case are the same because every state is filled.
    """
    name = "Dynamic Programming (Held-Karp)"
    n = len(dist)
    if n <= 2:
        return _trivial(dist, name)

    full = 1 << n
    dp = [[INF] * n for _ in range(full)]
    parent = [[-1] * n for _ in range(full)]
    dp[1][0] = 0.0
    states = 0

    for mask in range(1, full):
        if not (mask & 1):              # every path starts at the depot
            continue
        row = dp[mask]
        for j in range(n):
            cur = row[j]
            if cur == INF or not (mask >> j) & 1:
                continue
            dj = dist[j]
            for k in range(1, n):
                if (mask >> k) & 1:
                    continue
                states += 1
                nmask = mask | (1 << k)
                cand = cur + dj[k]
                if cand < dp[nmask][k]:
                    dp[nmask][k] = cand
                    parent[nmask][k] = j

    last_mask = full - 1
    best_cost, last = INF, -1
    for j in range(1, n):
        c = dp[last_mask][j] + dist[j][0]
        if c < best_cost:
            best_cost, last = c, j

    # Reconstruct the route by following parent pointers backwards
    route, mask, cur = [0], last_mask, last
    while cur != 0:
        route.append(cur)
        prev = parent[mask][cur]
        mask ^= 1 << cur
        cur = prev
    route.append(0)
    route.reverse()
    table_cells = full * n
    return {"algorithm": name, "route": route, "cost": best_cost,
            "stats": {"transitions": states, "table_cells": table_cells}}


# ---------------------------------------------------------------------------
# 4. Branch and Bound - Least-Cost search with reduced cost matrix, exact
# ---------------------------------------------------------------------------
def _reduce(matrix):
    """
    Row reduction then column reduction (in place).
    Returns the total amount subtracted = a lower bound on any tour
    that can still be built from this matrix.
    """
    n = len(matrix)
    total = 0.0
    for i in range(n):
        m = min(matrix[i])
        if 0 < m < INF:
            total += m
            row = matrix[i]
            for j in range(n):
                if row[j] < INF:
                    row[j] -= m
    for j in range(n):
        m = min(matrix[i][j] for i in range(n))
        if 0 < m < INF:
            total += m
            for i in range(n):
                if matrix[i][j] < INF:
                    matrix[i][j] -= m
    return total


def branch_and_bound(dist, node_limit=5_000_000):
    """
    Least-Cost (best-first) Branch and Bound, as in Horowitz-Sahni.

    Each node in the state-space tree is a partial route with a reduced
    cost matrix. Its bound is:
        cost(child) = cost(parent) + M_parent[i][j] + reduction(M_child)
    where M_child is M_parent with row i and column j set to INF and
    M[j][0] set to INF (so the tour cannot close early).

    The node with the smallest bound is expanded first (min-heap).
    A node is pruned when its bound >= the best complete tour found so far.
    The greedy route is used as the initial upper bound, so pruning starts
    immediately.

    Time:  each node costs O(n^2) to reduce. Best case ~O(n^3) when the
           bound is tight; worst case explores the whole tree -> O(n^2 * n!).
    Space: the priority queue can hold many nodes, each with an n x n
           matrix -> O(n^2 * number_of_live_nodes); worst case exponential.
    """
    name = "Branch and Bound (LC)"
    n = len(dist)
    if n <= 2:
        return _trivial(dist, name)

    base = [[INF if i == j else dist[i][j] for j in range(n)] for i in range(n)]
    root_bound = _reduce(base)

    # Initial upper bound from greedy - prunes many nodes early
    greedy = nearest_neighbour(dist)
    best_cost, best_route = greedy["cost"], greedy["route"]
    eps = 1e-9

    counter = itertools.count()          # tie-breaker for the heap
    heap = [(root_bound, next(counter), 0, [0], base)]
    expanded = generated = pruned = 0
    max_live = 1

    while heap:
        bound, _, city, path, matrix = heapq.heappop(heap)
        if bound >= best_cost - eps:
            pruned += 1
            continue                     # no better tour below this node
        expanded += 1
        if expanded > node_limit:
            break

        if len(path) == n:               # all cities placed; close the tour
            total = route_cost(dist, path + [0])
            if total < best_cost - eps:
                best_cost, best_route = total, path + [0]
            continue

        for nxt in range(1, n):
            if matrix[city][nxt] == INF:
                continue
            child = [row[:] for row in matrix]
            for k in range(n):
                child[city][k] = INF     # leave `city` only once
                child[k][nxt] = INF      # enter `nxt` only once
            child[nxt][0] = INF          # no early return to depot
            cbound = bound + matrix[city][nxt] + _reduce(child)
            generated += 1
            if cbound < best_cost - eps:
                heapq.heappush(heap, (cbound, next(counter), nxt, path + [nxt], child))
            else:
                pruned += 1
        max_live = max(max_live, len(heap))

    return {"algorithm": name, "route": best_route, "cost": best_cost,
            "stats": {"nodes_expanded": expanded, "nodes_generated": generated,
                      "nodes_pruned": pruned, "max_live_nodes": max_live,
                      "root_lower_bound": round(root_bound, 2),
                      "completed": expanded <= node_limit}}


ALGORITHMS = {
    "greedy": nearest_neighbour,
    "dp": held_karp,
    "bnb": branch_and_bound,
    "brute": brute_force,
}

# Practical limits used by the web interface (exact methods blow up)
MAX_N = {"greedy": 2000, "dp": 18, "bnb": 14, "brute": 10}
