# Smart Delivery Route Planning System (DAA Mini Project)

Finds the shortest delivery route through many stops (Travelling Salesman Problem) and compares four algorithms:

| Algorithm | Technique | Time | Space | Optimal? |
|---|---|---|---|---|
| Nearest Neighbour | Greedy | Θ(n²) | Θ(n) | No |
| Held-Karp | Dynamic Programming | Θ(n²·2ⁿ) | Θ(n·2ⁿ) | Yes |
| LC Branch and Bound | Branch & Bound | O(n²·n!) worst | O(n²·live nodes) | Yes |
| Brute Force | Exhaustive | Θ(n·n!) | Θ(n) | Yes |

## Run it
```
pip install -r requirements.txt
python app.py                # open http://127.0.0.1:5000
python tests/test_tsp.py     # unit tests
python benchmark.py          # re-measure (about 2 minutes); --quick for ~30 s
```

## Folders
- `algorithms/tsp.py` – all four algorithms (written from scratch)
- `app.py`, `templates/`, `static/` – web interface (map, results, processing log, tap sparkles)
- `data/` – sample inputs (12 Hyderabad localities, city grids)
- `results/` – measured times (`benchmark.json`, `benchmark.csv`) and graphs
- `docs/` – presentation (.pptx) and screenshots of the running app
- `tests/` – unit tests (DP and B&B checked against brute force)

## Libraries
Flask (web server), Matplotlib (graphs). Browser side uses plain HTML/CSS/JavaScript Canvas; Google Fonts (Fredoka, Nunito) load when online and fall back to system fonts offline.

## Before submitting
Fill in group number, member names, enrollment numbers and faculty name on slide 1 of the presentation.
